
#include "dpi_adder.h"

void add(int* a, int b)
{
	*a += b;
}

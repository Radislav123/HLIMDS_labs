Example of connecting randomized classes to a module.  In particular,
multiple random generators are created to drive multiple ports.  This example
only shows stimulus generation for clarity, there is no expected result
checking.

#! /bin/sh
rm -f transcript *.wlf core* workingExclude.cov
rm -f *.dll *.exp *.lib *.obj *.sl *.o *.so
rm -f *.vstf *.h results.txt *.ucdb *.dump
rm -rf work
exit 0

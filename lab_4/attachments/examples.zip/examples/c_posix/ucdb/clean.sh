#! /bin/sh
rm -f transcript *.wlf core* workingExclude.cov
rm -f *.dll *.exp *.lib *.obj *.sl *.o *.so *.ucdb ucdbdump
rm -f vsim_stacktrace.vstf *.h test.dump
rm -rf work
exit 0

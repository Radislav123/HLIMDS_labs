#! /bin/sh
rm -f transcript *.wlf core* workingExclude.cov
rm -f *.dll *.exp *.lib *.obj *.sl *.o *.so *.ucdb ucdbdump ucdbdump.exe
rm -f vsim_stacktrace.vstf *.h test.dump *.manifest
rm -rf work
exit 0
